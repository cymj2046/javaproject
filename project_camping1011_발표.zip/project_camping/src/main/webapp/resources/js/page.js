function pageClick(pageNo){
	
	let frm = document.form1;
	frm.currentPage.value = pageNo;
	frm.submit();
}

function goURL(url){
	location.href = url;
}