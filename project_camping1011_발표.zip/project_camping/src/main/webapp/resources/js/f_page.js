function f_pageClick(pageNo){
	
	let frm = document.form2;
	frm.f_currentPage.value = pageNo;
	frm.submit();
}
