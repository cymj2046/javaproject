package com.example.project.dao;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.example.project.vo.MemberVO;

@Repository
public class MemberDAOImpl implements MemberDAO {

	@Inject
	private SqlSession sqlSession;

	// 회원 가입 
	@Override
	public void insertMember(MemberVO vo) {
		sqlSession.insert("member.insertMember", vo);

	}

	//  회원 정보 (관리자 모드, 현재 에러)
	@Override
	public MemberVO viewMember(String L_id) {
		return sqlSession.selectOne("member.viewMember",L_id);
	}

	//  회원 리스트 (관리자 모드, 현재 에러)
	@Override
	public List<MemberVO> memberList() {
		return sqlSession.selectList("member.memberList");

	}

	// 아이디 중복 체크
	@Override
	public int idCheck(MemberVO vo) throws Exception {

		int result = sqlSession.selectOne("member.idcheck", vo);
		return result;
	}

}
