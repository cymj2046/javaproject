package com.example.project.vo;

import java.sql.Date;

public class CampsiteVO {
	private int c_contentId;
	private String c_facltNm;
	private String c_intro;
	private String c_addr1;
	private String c_addr2;
	private double c_mapX;
	private double c_mapY;
	private String c_tel;
	private String c_homepage;
	private String c_firstImageUrl;
	
	
	//getter/setter
	public int getC_contentId() {
		return c_contentId;
	}


	public void setC_contentId(int c_contentId) {
		this.c_contentId = c_contentId;
	}


	public String getC_facltNm() {
		return c_facltNm;
	}


	public void setC_facltNm(String c_facltNm) {
		this.c_facltNm = c_facltNm;
	}


	public String getC_intro() {
		return c_intro;
	}


	public void setC_intro(String c_intro) {
		this.c_intro = c_intro;
	}


	public String getC_addr1() {
		return c_addr1;
	}


	public void setC_addr1(String c_addr1) {
		this.c_addr1 = c_addr1;
	}


	public String getC_addr2() {
		return c_addr2;
	}


	public void setC_addr2(String c_addr2) {
		this.c_addr2 = c_addr2;
	}


	public double getC_mapX() {
		return c_mapX;
	}


	public void setC_mapX(double c_mapX) {
		this.c_mapX = c_mapX;
	}


	public double getC_mapY() {
		return c_mapY;
	}


	public void setC_mapY(double c_mapY) {
		this.c_mapY = c_mapY;
	}


	public String getC_tel() {
		return c_tel;
	}


	public void setC_tel(String c_tel) {
		this.c_tel = c_tel;
	}


	public String getC_homepage() {
		return c_homepage;
	}


	public void setC_homepage(String c_homepage) {
		this.c_homepage = c_homepage;
	}


	public String getC_firstImageUrl() {
		return c_firstImageUrl;
	}


	public void setC_firstImageUrl(String c_firstImageUrl) {
		this.c_firstImageUrl = c_firstImageUrl;
	}


	@Override
	public String toString() {
		return "CampsiteVO [c_contentId=" + c_contentId + ", c_facltNm=" + c_facltNm + ", c_intro=" + c_intro
				+ ", c_addr1=" + c_addr1 + ", c_addr2=" + c_addr2 + ", c_mapX=" + c_mapX + ", c_mapY=" + c_mapY
				+ ", c_tel=" + c_tel + ", c_homepage=" + c_homepage + ", c_firstImageUrl=" + c_firstImageUrl + "]";
	}
	
}
