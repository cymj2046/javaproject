package com.example.project.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.example.project.dao.FestivalDAO;
import com.example.project.vo.FestivalSearchVo;
import com.example.project.vo.FestivalVO;

@Service 
public class FestivalServiceImpl implements FestivalService {
	
	@Inject
	FestivalDAO festivalDao;

	@Override
	public FestivalVO f_read(int f_code) throws Exception {
		return festivalDao.f_read(f_code);
	}

	@Override
	public List<FestivalVO> f_listAll(FestivalSearchVo festivalSearchVo) throws Exception {
		return festivalDao.f_listAll(festivalSearchVo);
	}

	@Override
	public int f_totalCount(FestivalSearchVo festivalSearchVo) throws Exception {
		return festivalDao.f_totalCount(festivalSearchVo);
	}

	@Override
	public void f_create(FestivalVO fvo) throws Exception {
		festivalDao.f_create(fvo);

	}

	@Override
	public void f_update(FestivalVO fvo) throws Exception {
		festivalDao.f_update(fvo);

	}

	@Override
	public void f_delete(int f_code) throws Exception {
		festivalDao.f_delete(f_code);

	}

}
