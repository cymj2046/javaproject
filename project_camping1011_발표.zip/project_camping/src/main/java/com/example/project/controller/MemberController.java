package com.example.project.controller;

import java.util.List;
import java.util.logging.Logger;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.project.service.MemberService;
import com.example.project.vo.MemberVO;

@Controller
public class MemberController {

	@Inject
	private MemberService memberService;

	// 회원등록 폼, 회원 가입 폼
	@RequestMapping("member/write")
	public String memberWrite() {
		return "member/member_write";
	}

	// 회원 등록, 결과
	@RequestMapping("member/insert")
	public String memberInsert(@ModelAttribute MemberVO vo) {
		memberService.insertMember(vo);
		// redirect jsp 위치를 잘못 지정함 ㅠㅠ
		return "redirect:/login/login";
	}

	// 회원 목록 -> 관리자 페이이지로 만들어서, 수정 삭제 리스트 확인. or 회원이 정보 수정 및 삭제
	@RequestMapping("member/list")
	public String memberList(Model model) {
		List<MemberVO> list = memberService.memberList();
		model.addAttribute("list", list);
		return "member/member_list";
	}

	// 회원 상세 정보(관리자 모드)
	public String memberView(@RequestParam String L_id, Model modle) {
		modle.addAttribute("dto", memberService.viewMember(L_id));
		return "member/member_view";
	}

	// 아이디 중복 체크 idCheck
	public int idCheck(MemberVO vo) throws Exception {
		int result = memberService.idCheck(vo);
		return result;
	}

	// 회원가입 idCheck

	@RequestMapping("member/member_register")
	public String postRegister(MemberVO vo) throws Exception {
		// Logger.info("post register");
		int result = memberService.idCheck(vo);
		try {
			if (result == 1) {
				return "member/member_write";
			} else if (result == 0) {
				memberService.register(vo);
			}
		} catch (Exception e) {
			throw new RuntimeException();
		}
		return "redirect:/";
	}
}
