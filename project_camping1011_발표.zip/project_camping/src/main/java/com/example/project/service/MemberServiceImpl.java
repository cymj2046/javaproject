package com.example.project.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.example.project.dao.MemberDAO;
import com.example.project.vo.MemberVO;

@Service
public class MemberServiceImpl implements MemberService {

	@Inject
	private MemberDAO memberDao;

	//회원 가입
	@Override
	public void insertMember(MemberVO vo) {
		memberDao.insertMember(vo);
	}

	//상세 정보 (관리자 모드)
	@Override
	public MemberVO viewMember(String L_id) {
		return memberDao.viewMember(L_id);
	}

	//회원 리스트 (관리자 모드)
	@Override
	public List<MemberVO> memberList() {
		return memberDao.memberList();
	}

	@Override
	public int idCheck(MemberVO vo) throws Exception {
		int result = memberDao.idCheck(vo);
		return result;
	}

	@Override
	public void register(MemberVO vo) throws Exception {
		// TODO Auto-generated method stub
		
	}

}
