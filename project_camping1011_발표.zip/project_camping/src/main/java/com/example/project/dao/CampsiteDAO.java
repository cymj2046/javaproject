package com.example.project.dao;

import java.util.List;

import com.example.project.vo.CampsiteSearchVo;
import com.example.project.vo.CampsiteVO;


public interface CampsiteDAO {
	
	//상세보기
	public CampsiteVO read(int bno) throws Exception;

	public List<CampsiteVO> listAll(CampsiteSearchVo campsiteSearchVo) throws Exception;
	
	public int totalCount(CampsiteSearchVo campsiteSearchVo) throws Exception;
}
