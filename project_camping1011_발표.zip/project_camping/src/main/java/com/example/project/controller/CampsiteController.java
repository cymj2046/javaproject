package com.example.project.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.example.project.service.CampsiteService;
import com.example.project.vo.CampsiteSearchVo;
import com.example.project.vo.CampsiteVO;

@Controller
public class CampsiteController {

	@Inject
	private CampsiteService campsiteService;

	
    // 목록보기 ==> 검색기능
	@RequestMapping("campsite/list")
	
	public ModelAndView list(
			
			/*
			@RequestParam(defaultValue="all") String searchOption,
			@RequestParam(defaultValue="") String keyword,
			@RequestParam(defaultValue="1") int currentPage, // 현재 페이지 번호
			@RequestParam(defaultValue="10") int listCount, // 목록에 몇개씩 보여줄지
			@RequestParam(defaultValue="5") int pageCount // 페이지 번호를 몇개씩 보여줄지
			*/
			CampsiteSearchVo campsiteSearchVo
	) throws Exception{
		campsiteSearchVo.setLimitStart(campsiteSearchVo.getCurrentPage() * campsiteSearchVo.getListCount() - campsiteSearchVo.getListCount());
		
		System.out.println(campsiteSearchVo);
		
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("list", campsiteService.listAll(campsiteSearchVo));
		map.put("totalCount", campsiteService.totalCount(campsiteSearchVo));
		map.put("campsiteSearchVo", campsiteSearchVo);
		
		
		ModelAndView mav = new ModelAndView();
		mav.addObject("map", map);
		mav.setViewName("campsite/list"); 
		
		return mav;
		
		//System.out.println("##### campsite/list");
	}
	
	// 캠핑장명 -> 상세보기
	@RequestMapping("/campsite/view")
	public ModelAndView view(int c_contentId, HttpSession session) throws Exception {
		//campsiteService.increaseViewcnt(c_contentId, session);
		ModelAndView mav = new ModelAndView();

		mav.addObject("dto", campsiteService.read(c_contentId));
		mav.setViewName("/campsite/view");
		return mav;
	}
}
