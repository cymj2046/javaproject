package com.example.project.dao;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.example.project.vo.CampsiteSearchVo;
import com.example.project.vo.CampsiteVO;

@Repository //빈등록
public class CampsiteDAOImpl implements CampsiteDAO {

	@Inject //주입
	private SqlSession sqlSession;
	
	@Override
	public CampsiteVO read(int bno) throws Exception {
		return sqlSession.selectOne("campsite.view", bno);
	}
	
	@Override
	public List<CampsiteVO> listAll(CampsiteSearchVo campsiteSearchVo) throws Exception {
		return sqlSession.selectList("campsite.listAll", campsiteSearchVo);
	}
	
	@Override
	public int totalCount(CampsiteSearchVo campsiteSearchVo) throws Exception {
		return sqlSession.
				selectOne("campsite.totalCount", campsiteSearchVo);
	}
}
