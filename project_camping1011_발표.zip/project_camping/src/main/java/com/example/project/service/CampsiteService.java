package com.example.project.service;

import java.util.List;

import javax.servlet.http.HttpSession;

import com.example.project.vo.CampsiteSearchVo;
import com.example.project.vo.CampsiteVO;

	
public interface CampsiteService {

	//조회
	public CampsiteVO read(int bno) throws Exception;
	
	// 캠핑장 목록보기 => 검색기능
	public List<CampsiteVO> listAll(CampsiteSearchVo campsiteSearchVo) throws Exception;

	// 리스트 목록 갯수 체크
	public int totalCount(CampsiteSearchVo campsiteSearchVo) throws Exception;
	
}
