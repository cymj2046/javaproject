package com.example.project.dao;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.example.project.vo.FestivalSearchVo;
import com.example.project.vo.FestivalVO;

@Repository //빈등록
public class FestivalDAOImpl implements FestivalDAO {
	
	@Inject //주입
	SqlSession f_sqlSession;

	@Override
	public FestivalVO f_read(int f_code) throws Exception {
		return f_sqlSession.selectOne("festival.f_view", f_code);
	}

	@Override
	public List<FestivalVO> f_listAll(FestivalSearchVo festivalSearchVo) throws Exception {
		return f_sqlSession.selectList("festival.f_listAll", festivalSearchVo);
	}

	@Override
	public int f_totalCount(FestivalSearchVo festivalSearchVo) throws Exception {
		return f_sqlSession.selectOne("festival.f_totalCount", festivalSearchVo) ;
	}

	@Override
	public void f_create(FestivalVO fvo) throws Exception {
		f_sqlSession.insert("festival.f_insert", fvo);

	}

	@Override
	public void f_update(FestivalVO fvo) throws Exception {
		f_sqlSession.update("festival.f_update", fvo);

	}

	@Override
	public void f_delete(int f_code) throws Exception {
		f_sqlSession.delete("festival.f_delete", f_code);

	}

}
