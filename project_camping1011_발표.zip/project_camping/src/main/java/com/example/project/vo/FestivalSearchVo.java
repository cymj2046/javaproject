package com.example.project.vo;

public class FestivalSearchVo {
	
	private String f_searchOption = "all";
	private String f_keyword = "";
	private int f_currentPage = 1; // 현재 페이지 번호
	private int f_listCount = 10; // 목록에 몇개씩 보여줄지
	private int f_pageCount = 5; // 페이지 번호를 몇개씩 보여줄지
	private int f_limitStart = 0; // SQL limit 시작 번호
	
	
	public String getF_searchOption() {
		return f_searchOption;
	}
	public void setF_searchOption(String f_searchOption) {
		this.f_searchOption = f_searchOption;
	}
	public String getF_keyword() {
		return f_keyword;
	}
	public void setF_keyword(String f_keyword) {
		this.f_keyword = f_keyword;
	}
	public int getF_currentPage() {
		return f_currentPage;
	}
	public void setF_currentPage(int f_currentPage) {
		this.f_currentPage = f_currentPage;
	}
	public int getF_listCount() {
		return f_listCount;
	}
	public void setF_listCount(int f_listCount) {
		this.f_listCount = f_listCount;
	}
	public int getF_pageCount() {
		return f_pageCount;
	}
	public void setF_pageCount(int f_pageCount) {
		this.f_pageCount = f_pageCount;
	}
	public int getF_limitStart() {
		return f_limitStart;
	}
	public void setF_limitStart(int f_limitStart) {
		this.f_limitStart = f_limitStart;
	}
	
	
	@Override
	public String toString() {
		return "FestivalSearchVo [f_searchOption=" + f_searchOption + ", f_keyword=" + f_keyword + ", f_currentPage="
				+ f_currentPage + ", f_listCount=" + f_listCount + ", f_pageCount=" + f_pageCount + ", f_limitStart="
				+ f_limitStart + "]";
	}
}
