package com.example.project.dao;

import javax.servlet.http.HttpSession;

import com.example.project.vo.MemberVO;

public interface LoginDAO {
	
	public boolean loginCheck(MemberVO vo);
	
	public MemberVO viewMember(MemberVO vo);
	
	public void logout(HttpSession session);

}
