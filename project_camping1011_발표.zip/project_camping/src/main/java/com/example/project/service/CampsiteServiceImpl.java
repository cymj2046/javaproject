package com.example.project.service;

import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Service;

import com.example.project.dao.CampsiteDAO;
import com.example.project.vo.CampsiteSearchVo;
import com.example.project.vo.CampsiteVO;

@Service 
public class CampsiteServiceImpl implements CampsiteService {

	@Inject
	private CampsiteDAO campsiteDao;
	

	@Override
	public CampsiteVO read(int bno) throws Exception {
		return campsiteDao.read(bno);
	}
	
	@Override
	public List<CampsiteVO> listAll(CampsiteSearchVo campsiteSearchVo) throws Exception {
		return campsiteDao.listAll(campsiteSearchVo);
	}
	
	@Override
	public int totalCount(CampsiteSearchVo campsiteSearchVo) throws Exception {
		return campsiteDao.totalCount(campsiteSearchVo);
	}
}
