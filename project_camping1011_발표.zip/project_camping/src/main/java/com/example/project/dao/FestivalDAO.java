package com.example.project.dao;

import java.util.List;

import com.example.project.vo.FestivalSearchVo;
import com.example.project.vo.FestivalVO;

public interface FestivalDAO {
	
	//조회
	public FestivalVO f_read(int f_code) throws Exception;

	//목록보기 => 검색기능
	public List<FestivalVO> f_listAll(FestivalSearchVo festivalSearchVo) throws Exception;
	
	// 리스트 목록 갯수 체크
	public int f_totalCount(FestivalSearchVo festivalSearchVo) throws Exception;
	
	 // 삽입
	public void f_create(FestivalVO fvo) throws Exception;
		
	// 수정
	public void f_update(FestivalVO fvo) throws Exception;

	//삭제
	public void f_delete(int f_code) throws Exception;


}
