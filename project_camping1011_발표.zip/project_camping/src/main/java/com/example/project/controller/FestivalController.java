package com.example.project.controller;

import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;


import com.example.project.service.FestivalService;
import com.example.project.vo.FestivalSearchVo;


@Controller
public class FestivalController {
	
	@Inject
	FestivalService festivalService;

	
    // 목록보기 ==> 검색기능
	@RequestMapping("festival/flist")
	
	public ModelAndView f_list(
			
			/*
			@RequestParam(defaultValue="all") String searchOption,
			@RequestParam(defaultValue="") String keyword,
			@RequestParam(defaultValue="1") int currentPage, // 현재 페이지 번호
			@RequestParam(defaultValue="10") int listCount, // 목록에 몇개씩 보여줄지
			@RequestParam(defaultValue="5") int pageCount // 페이지 번호를 몇개씩 보여줄지
			*/
			FestivalSearchVo festivalSearchVo
	) throws Exception{
		festivalSearchVo.setF_limitStart(festivalSearchVo.getF_currentPage() * festivalSearchVo.getF_listCount() - festivalSearchVo.getF_listCount());
		
		System.out.println(festivalSearchVo);
		
		Map<String, Object> f_map = new HashMap<String, Object>();
		f_map.put("f_list", festivalService.f_listAll(festivalSearchVo));
		f_map.put("f_totalCount", festivalService.f_totalCount(festivalSearchVo));
		f_map.put("festivalSearchVo", festivalSearchVo);
		
		
		ModelAndView f_mav = new ModelAndView();
		f_mav.addObject("f_map", f_map);
		f_mav.setViewName("festival/flist"); 
		
		return f_mav;
		
		//System.out.println("##### campsite/list");
	}
	
	// 캠핑장명 -> 상세보기
	@RequestMapping("/festival/fview")
	public ModelAndView f_view(int f_code, HttpSession f_session) throws Exception {
		//campsiteService.increaseViewcnt(c_contentId, session);
		ModelAndView f_mav = new ModelAndView();

		f_mav.addObject("dto", festivalService.f_read(f_code));
		f_mav.setViewName("/festival/fview");
		return f_mav;
	}
}


