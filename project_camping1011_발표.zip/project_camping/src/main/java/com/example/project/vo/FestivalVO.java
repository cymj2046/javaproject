package com.example.project.vo;

import java.sql.Date;

public class FestivalVO {
	
	private int f_code;
	private String f_name;
	private String f_place;
	private Date f_startDate;
	private Date f_endDate;
	private String f_content;
	private String f_agency;
	private String f_tel;
	private String f_homepage;
	private String f_addr;
	private double f_mapX;
	private double f_mapY;
	
	
	public int getF_code() {
		return f_code;
	}
	public void setF_code(int f_code) {
		this.f_code = f_code;
	}
	public String getF_name() {
		return f_name;
	}
	public void setF_name(String f_name) {
		this.f_name = f_name;
	}
	public String getF_place() {
		return f_place;
	}
	public void setF_place(String f_place) {
		this.f_place = f_place;
	}
	public Date getF_startDate() {
		return f_startDate;
	}
	public void setF_startDate(Date f_startDate) {
		this.f_startDate = f_startDate;
	}
	public Date getF_endDate() {
		return f_endDate;
	}
	public void setF_endDate(Date f_endDate) {
		this.f_endDate = f_endDate;
	}
	public String getF_content() {
		return f_content;
	}
	public void setF_content(String f_content) {
		this.f_content = f_content;
	}
	public String getF_agency() {
		return f_agency;
	}
	public void setF_agency(String f_agency) {
		this.f_agency = f_agency;
	}
	public String getF_tel() {
		return f_tel;
	}
	public void setF_tel(String f_tel) {
		this.f_tel = f_tel;
	}
	public String getF_homepage() {
		return f_homepage;
	}
	public void setF_homepage(String f_homepage) {
		this.f_homepage = f_homepage;
	}
	public String getF_addr() {
		return f_addr;
	}
	public void setF_addr(String f_addr) {
		this.f_addr = f_addr;
	}
	public double getF_mapX() {
		return f_mapX;
	}
	public void setF_mapX(double f_mapX) {
		this.f_mapX = f_mapX;
	}
	public double getF_mapY() {
		return f_mapY;
	}
	public void setF_mapY(double f_mapY) {
		this.f_mapY = f_mapY;
	}
	
	
	@Override
	public String toString() {
		return "FestivalVO [f_code=" + f_code + ", f_name=" + f_name + ", f_place=" + f_place + ", f_startDate="
				+ f_startDate + ", f_endDate=" + f_endDate + ", f_content=" + f_content + ", f_agency=" + f_agency
				+ ", f_tel=" + f_tel + ", f_homepage=" + f_homepage + ", f_addr=" + f_addr + ", f_mapX=" + f_mapX
				+ ", f_mapY=" + f_mapY + "]";
	}
}
