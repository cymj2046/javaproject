package com.example.project.service;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Service;

import com.example.project.dao.LoginDAO;
import com.example.project.vo.MemberVO;

@Service
public class LoginServiceImpl implements LoginService {

	@Inject
	private LoginDAO loginDAO;
	
	@Override
	public boolean loginCheck(MemberVO vo, HttpSession session) {
		boolean result =loginDAO.loginCheck(vo);
		if(result) {
			MemberVO vo2 = viewMember(vo); //id, pw 같은 모든 값을  vo2에 설정 
			session.setAttribute("L_id", vo2.getL_id());
			session.setAttribute("L_name",vo2.getL_name());
		}
			
		return result;
	}
	@Override
	public MemberVO viewMember(MemberVO vo) {
		return loginDAO.viewMember(vo);
	}

	@Override
	public void logout(HttpSession session) {
		session.invalidate();

	}

}
