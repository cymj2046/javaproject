package com.example.project.vo;


public class MemberVO {
	private String L_id;
	private String L_pw;
	private String L_name;
	private String L_email;
	
	public String getL_id() {
		return L_id;
	}
	public void setL_id(String l_id) {
		L_id = l_id;
	}
	public String getL_pw() {
		return L_pw;
	}
	public void setL_pw(String l_pw) {
		L_pw = l_pw;
	}
	public String getL_name() {
		return L_name;
	}
	public void setL_name(String l_name) {
		L_name = l_name;
	}
	public String getL_email() {
		return L_email;
	}
	public void setL_email(String l_email) {
		L_email = l_email;
	}
	@Override
	public String toString() {
		return "MemberVO [L_id=" + L_id + ", L_pw=" + L_pw + ", L_name=" + L_name + ", L_email=" + L_email + "]";
	}
	

}