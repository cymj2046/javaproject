package com.example.project.vo;

public class CampsiteSearchVo {
	private String searchOption = "all";
	private String keyword = "";
	private int currentPage = 1; // 현재 페이지 번호
	private int listCount = 10; // 목록에 몇개씩 보여줄지
	private int pageCount = 5; // 페이지 번호를 몇개씩 보여줄지
	private int limitStart = 0; // SQL limit 시작 번호
	
	public String getSearchOption() {
		return searchOption;
	}
	public void setSearchOption(String searchOption) {
		this.searchOption = searchOption;
	}
	public String getKeyword() {
		return keyword;
	}
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	public int getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}
	public int getListCount() {
		return listCount;
	}
	public void setListCount(int listCount) {
		this.listCount = listCount;
	}
	public int getPageCount() {
		return pageCount;
	}
	public void setPageCount(int pageCount) {
		this.pageCount = pageCount;
	}
	public int getLimitStart() {
		return limitStart;
	}
	public void setLimitStart(int limitStart) {
		this.limitStart = limitStart;
	}
	
	@Override
	public String toString() {
		return "CampsiteSearchVo [searchOption=" + searchOption + ", keyword=" + keyword + ", currentPage="
				+ currentPage + ", listCount=" + listCount + ", pageCount=" + pageCount + ", limitStart=" + limitStart
				+ "]";
	}
}
