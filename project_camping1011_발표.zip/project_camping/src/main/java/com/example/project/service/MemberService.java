package com.example.project.service;

import java.util.List;

import com.example.project.vo.MemberVO;

public interface MemberService {

	// 회원 목록 (관리자 모드)
	public List<MemberVO> memberList();

	// 회원 가입
	public void insertMember(MemberVO vo);

	// 회원 상세 정보 (관리자 모드)
	public MemberVO viewMember(String L_id);
	
	public int idCheck(MemberVO vo) throws Exception;

	public void register(MemberVO vo) throws Exception;

}
