package com.example.project.dao;

import java.util.List;

import com.example.project.vo.MemberVO;

public interface MemberDAO {

	// 리스트 (관리자 모드, 현재 에러)
	public List<MemberVO> memberList();

	// 회원 가입
	public void insertMember(MemberVO vo);

	// 회원 정보 (관리자 모드, 현재 에러)
	public MemberVO viewMember(String L_id);


	public int idCheck(MemberVO vo) throws Exception;

}
